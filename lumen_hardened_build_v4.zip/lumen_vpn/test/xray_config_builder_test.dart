import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:lumen_vpn/core/xray_config_builder.dart';

VlessReality profile({String ip = '203.0.113.10'}) => VlessReality(
  serverIp: ip, port: 443,
  uuid: '11111111-2222-3333-4444-555555555555',
  sni: 'www.example.com', publicKey: 'A' * 43, shortId: 'a1b2c3d4',
);

Map<String, dynamic> built() => jsonDecode(jsonEncode(
  XrayConfigBuilder.build(profile(), socksPort: 40123).xray,
)) as Map<String, dynamic>;

void main() {
  test('inbound is native TUN', () {
    final i = (built()['inbounds'] as List).single as Map;
    expect(i['protocol'], 'tun');
    expect(i['settings'], isA<Map>());
  });

  test('non-TUN inbound is rejected', () {
    final c = built();
    ((c['inbounds'] as List).first as Map)['protocol'] = 'socks';
    expect(() => XrayConfigBuilder.assertHardened(c), throwsA(isA<ConfigException>()));
  });

  test('loglevel debug rejected', () {
    expect(() => XrayConfigBuilder.build(profile(), socksPort: 40123, logLevel: 'debug'), throwsA(isA<ConfigException>()));
  });

  test('freedom outbound rejected', () {
    final c = built();
    (c['outbounds'] as List).add({'tag': 'direct', 'protocol': 'freedom'});
    expect(() => XrayConfigBuilder.assertHardened(c), throwsA(isA<ConfigException>()));
  });

  test('server domain rejected', () {
    expect(() => XrayConfigBuilder.build(profile(ip: 'vpn.example.com'), socksPort: 40123), throwsA(isA<ConfigException>()));
  });

  test('secrets are redacted from toString', () {
    final c = XrayConfigBuilder.build(profile(), socksPort: 40123);
    expect(c.toString().contains(c.socksPass), isFalse);
    expect(profile().toString().contains('203.0.113.10'), isFalse);
  });
}
