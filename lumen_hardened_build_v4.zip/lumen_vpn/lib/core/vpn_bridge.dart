import 'dart:async';
import 'package:flutter/services.dart';

abstract interface class VpnBridge {
  Future<void> connect(String xrayConfigJson);
  Future<void> disconnect();
  Future<int> measurePing();
}

class NativeVpnBridge implements VpnBridge {
  static const _methods = MethodChannel('lumen/tunnel');
  static const _events = EventChannel('lumen/tunnel/events');

  Stream<String> get states => _events.receiveBroadcastStream().map((e) => e.toString());

  @override
  Future<void> connect(String xrayConfigJson) async {
    final result = await _methods.invokeMethod<String>('connect', {'envelope': xrayConfigJson});
    if (result == null) throw StateError('native_connect_failed');
  }

  @override
  Future<void> disconnect() async {
    await _methods.invokeMethod<void>('disconnect');
  }

  @override
  Future<int> measurePing() async => -1;
}
