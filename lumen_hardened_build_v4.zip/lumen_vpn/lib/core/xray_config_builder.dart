import 'dart:convert';
import 'dart:io' show InternetAddress, ServerSocket;
import 'dart:math';

/// Код ошибки без значений: исключения не должны содержать IP, ключи, UUID.
class ConfigException implements Exception {
  ConfigException(this.code);
  final String code;
  @override
  String toString() => 'ConfigException($code)';
}

/// Профиль VLESS + Reality (сюда парсер vless:// отдаст результат на Шаге 2).
/// toString() намеренно скрыт: случайный print/лог не должен светить секреты.
class VlessReality {
  const VlessReality({
    required this.serverIp,
    required this.port,
    required this.uuid,
    required this.sni,
    required this.publicKey,
    required this.shortId,
    this.fingerprint = 'chrome',
    this.flow = 'xtls-rprx-vision',
    this.spiderX = '/',
  });

  /// ТОЛЬКО IP-литерал. Домен нужно резолвить заранее, вне туннеля,
  /// иначе имя сервера утечёт в системный DNS (или получится петля).
  final String serverIp;
  final int port;
  final String uuid;
  final String sni;
  final String publicKey; // pbk
  final String shortId; // sid
  final String fingerprint; // fp
  final String flow;
  final String spiderX; // spx

  @override
  String toString() => 'VlessReality(<redacted>)';
}

/// Результат сборки: Xray-конфиг для нативного Android TUN fd.
class XrayRuntimeConfig {
  XrayRuntimeConfig._(this.xray, this.socksPort, this.socksUser, this.socksPass);

  final Map<String, dynamic> xray;
  // Kept only for compatibility with the existing Dart contract; native TUN mode does not use them.
  final int socksPort;
  final String socksUser;
  final String socksPass;

  String toEnvelope() => jsonEncode({
        'v': 2,
        'xray': xray,
        'socks': {'port': socksPort, 'user': socksUser, 'pass': socksPass},
      });

  @override
  String toString() => 'XrayRuntimeConfig(<redacted>)';
}

abstract final class XrayConfigBuilder {
  static const loopback = '127.0.0.1';

  static final _uuid = RegExp(
      r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$');
  static final _pbk = RegExp(r'^[A-Za-z0-9_-]{43}$');
  static final _sid = RegExp(r'^([0-9a-fA-F]{2}){0,8}$');
  static final _host = RegExp(
      r'^(?=.{1,253}$)([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$');
  static const _fps = {
    'chrome', 'firefox', 'safari', 'ios', 'android', 'edge', '360', 'qq',
    'random', 'randomized',
  };
  static const _flows = {'', 'xtls-rprx-vision'};
  static const _logLevels = {'none', 'warning'};

  /// Свободный порт на loopback. Вызывайте непосредственно перед build().
  static Future<int> pickLoopbackPort() async {
    final s = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    final port = s.port;
    await s.close();
    return port;
  }

  static XrayRuntimeConfig build(
    VlessReality p, {
    required int socksPort,
    String logLevel = 'none',
    Random? random,
  }) {
    if (!_logLevels.contains(logLevel)) throw ConfigException('log_level');
    if (socksPort < 1024 || socksPort > 65535) throw ConfigException('socks_port');
    _validate(p);

    final rnd = random ?? Random.secure();
    final user = _token(rnd, 9);
    final pass = _token(rnd, 24);

    final cfg = <String, dynamic>{
      // ── Логи: никаких файлов, никакого stdout/logcat ──
      'log': {
        'loglevel': logLevel,
        'access': 'none',
        'error': 'none',
        'dnsLog': false,
      },

      // ── DNS: резолв ТОЛЬКО внутри ядра, DoH уходит через outbound proxy ──
      // Нет 'https+local://' и 'localhost' -> нет прямых системных запросов.
      'dns': {
        'servers': ['https://1.1.1.1/dns-query', 'https://9.9.9.9/dns-query'],
        'queryStrategy': 'UseIPv4', // AAAA не отдаём -> приложения не лезут в v6
        'tag': 'dns-internal',
      },

      // Android TUN fd is supplied by VpnService and injected by libv2ray.StartLoop.
      'inbounds': [
        {
          'tag': 'tun-in',
          'port': 0,
          'protocol': 'tun',
          'settings': {
            'mtu': 1500,
            'gateway': ['10.8.0.1/30', 'fd00:8::1/126'],
          },
        },
      ],

      // ── Outbounds: ЕДИНСТВЕННЫЙ выход наружу — proxy. Нет 'freedom' = нет прямого пути ──
      'outbounds': [
        {
          'tag': 'proxy',
          'protocol': 'vless',
          'settings': {
            'vnext': [
              {
                'address': p.serverIp,
                'port': p.port,
                'users': [
                  {
                    'id': p.uuid,
                    'encryption': 'none',
                    if (p.flow.isNotEmpty) 'flow': p.flow,
                  },
                ],
              },
            ],
          },
          'streamSettings': {
            'network': 'tcp',
            'security': 'reality',
            'realitySettings': {
              'serverName': p.sni,
              'fingerprint': p.fingerprint,
              'publicKey': p.publicKey,
              'shortId': p.shortId,
              'spiderX': p.spiderX,
            },
          },
        },
        {'tag': 'dns-out', 'protocol': 'dns'},
        {'tag': 'block', 'protocol': 'blackhole'},
      ],

      // ── Роутинг: порядок правил критичен (validate проверяет) ──
      'routing': {
        'domainStrategy': 'AsIs',
        'rules': [
          // 1) Любой DNS (порт 53, UDP/TCP) из туннеля -> встроенный DNS ядра
          {
            'type': 'field',
            'inboundTag': ['tun-in'],
            'port': '53',
            'outboundTag': 'dns-out',
          },
          // 3) IPv6 в чёрную дыру (дублирует блок на уровне TUN)
          {
            'type': 'field',
            'ip': ['::/0'],
            'outboundTag': 'block',
          },
          // 4) Всё остальное -> proxy
          {
            'type': 'field',
            'network': 'tcp,udp',
            'outboundTag': 'proxy',
          },
        ],
      },

      // ── Батарея: рвём простаивающие соединения, режем таймауты ──
      'policy': {
        'levels': {
          '0': {
            'handshake': 6,
            'connIdle': 180,
            'uplinkOnly': 2,
            'downlinkOnly': 4,
          },
        },
      },
      // Намеренно ОТСУТСТВУЮТ: api, stats, metrics, observatory, reverse.
    };

    assertHardened(cfg);
    return XrayRuntimeConfig._(cfg, socksPort, user, pass);
  }

  /// Последний рубеж: бросает ConfigException, если конфиг нарушает политику.
  /// Вызывается внутри build() и должен вызываться на нативной стороне повторно
  /// (defense in depth) перед запуском ядра.
  static void assertHardened(Map<String, dynamic> cfg) {
    final log = cfg['log'] as Map?;
    if (log == null ||
        !_logLevels.contains(log['loglevel']) ||
        log['access'] != 'none' ||
        log['error'] != 'none') {
      throw ConfigException('log');
    }

    for (final k in const ['api', 'stats', 'metrics', 'observatory', 'burstObservatory', 'reverse']) {
      if (cfg.containsKey(k)) throw ConfigException('forbidden_section');
    }

    final inbounds = cfg['inbounds'] as List?;
    if (inbounds == null || inbounds.isEmpty) throw ConfigException('inbounds');
    for (final raw in inbounds) {
      final i = raw as Map;
      if (i['protocol'] != 'tun') throw ConfigException('inbound_protocol');
    }

    final outbounds = cfg['outbounds'] as List?;
    if (outbounds == null || outbounds.isEmpty) throw ConfigException('outbounds');
    if ((outbounds.first as Map)['tag'] != 'proxy') throw ConfigException('default_outbound');
    if (outbounds.any((o) => (o as Map)['protocol'] == 'freedom')) {
      throw ConfigException('direct_outbound');
    }

    if ((cfg['dns'] as Map?)?['queryStrategy'] != 'UseIPv4') throw ConfigException('dns_strategy');

    final rules = ((cfg['routing'] as Map?)?['rules'] as List?) ?? const [];
    final dnsIdx = rules.indexWhere((r) {
      final m = r as Map;
      return m['port'] == '53' && m['outboundTag'] == 'dns-out';
    });
    final v6Idx = rules.indexWhere((r) {
      final m = r as Map;
      return m['outboundTag'] == 'block' && (m['ip'] as List?)?.contains('::/0') == true;
    });
    final catchIdx = rules.indexWhere((r) {
      final m = r as Map;
      return m['network'] == 'tcp,udp' && m['outboundTag'] == 'proxy';
    });
    if (dnsIdx < 0) throw ConfigException('dns_rule_missing');
    if (v6Idx < 0) throw ConfigException('ipv6_rule_missing');
    if (catchIdx < 0 || dnsIdx > catchIdx || v6Idx > catchIdx) {
      throw ConfigException('rule_order');
    }
  }

  static void _validate(VlessReality p) {
    final ip = InternetAddress.tryParse(p.serverIp);
    if (ip == null) throw ConfigException('server_not_ip'); // домен запрещён
    if (p.port < 1 || p.port > 65535) throw ConfigException('server_port');
    if (!_uuid.hasMatch(p.uuid)) throw ConfigException('uuid');
    if (!_host.hasMatch(p.sni)) throw ConfigException('sni');
    if (!_pbk.hasMatch(p.publicKey)) throw ConfigException('pbk');
    if (!_sid.hasMatch(p.shortId)) throw ConfigException('sid');
    if (!_fps.contains(p.fingerprint)) throw ConfigException('fp');
    if (!_flows.contains(p.flow)) throw ConfigException('flow');
    if (!p.spiderX.startsWith('/')) throw ConfigException('spx');
  }

  static String _token(Random r, int bytes) =>
      base64Url.encode(List<int>.generate(bytes, (_) => r.nextInt(256))).replaceAll('=', '');
}
