import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../ui/design/liquid_theme.dart';
import '../ui/design/spring.dart';

/// Выбранная тема (Riverpod). Персистентность (shared_preferences) — позже.
final themeEngineProvider =
    NotifierProvider<ThemeEngine, LiquidThemeId>(ThemeEngine.new);

class ThemeEngine extends Notifier<LiquidThemeId> {
  @override
  LiquidThemeId build() => LiquidThemeId.midnightAurora;

  void select(LiquidThemeId id) {
    if (id == state) return;
    HapticFeedback.selectionClick();
    state = id;
  }
}

class _LiquidScope extends InheritedWidget {
  const _LiquidScope({required this.theme, required super.child});
  final LiquidTheme theme;

  @override
  bool updateShouldNotify(_LiquidScope old) => !identical(theme, old.theme);
}

extension LiquidContext on BuildContext {
  LiquidTheme get liquid =>
      dependOnInheritedWidgetOfExactType<_LiquidScope>()!.theme;
}

/// Морфинг темы: одна пружина 0->1 между `_from` и `_to`.
/// Потребители перерисовываются на каждом кадре, но НЕ пересоздаются
/// (State/ключи/контроллеры сохраняются). Переключение можно прервать
/// на середине — новая пружина стартует с текущего промежуточного состояния.
class LiquidThemeHost extends ConsumerStatefulWidget {
  const LiquidThemeHost({super.key, required this.child});
  final Widget child;

  @override
  ConsumerState<LiquidThemeHost> createState() => _LiquidThemeHostState();
}

class _LiquidThemeHostState extends ConsumerState<LiquidThemeHost>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController.unbounded(vsync: this, value: 1);
  late LiquidTheme _from = LiquidThemes.of(ref.read(themeEngineProvider));
  late LiquidTheme _to = _from;

  void _retarget(LiquidTheme next) {
    _from = _from.lerp(_to, _c.value.clamp(0.0, 1.0));
    _to = next;
    _c.value = 0;
    _c.springTo(1, LiquidSprings.morph, velocity: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<LiquidThemeId>(
      themeEngineProvider,
      (_, next) => _retarget(LiquidThemes.of(next)),
    );
    return AnimatedBuilder(
      animation: _c,
      child: widget.child, // строится один раз
      builder: (_, child) => _LiquidScope(
        theme: _from.lerp(_to, _c.value.clamp(0.0, 1.0)),
        child: child!,
      ),
    );
  }
}
