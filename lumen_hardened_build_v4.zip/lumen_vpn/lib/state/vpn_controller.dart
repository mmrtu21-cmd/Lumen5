import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/vpn_bridge.dart';

enum VpnStatus { idle, handshake, connected }

@immutable
class VpnState {
  const VpnState({
    this.status = VpnStatus.idle,
    this.pingMs,
    this.serverName = 'Frankfurt',
    this.flag = '🇩🇪',
    this.protocol = 'VLESS',
    this.transport = 'Reality, XTLS Vision',
  });

  final VpnStatus status;
  final int? pingMs;
  final String serverName;
  final String flag;
  final String protocol;
  final String transport;

  VpnState copyWith({VpnStatus? status, int? pingMs, bool clearPing = false}) {
    return VpnState(
      status: status ?? this.status,
      pingMs: clearPing ? null : (pingMs ?? this.pingMs),
      serverName: serverName,
      flag: flag,
      protocol: protocol,
      transport: transport,
    );
  }
}

final vpnBridgeProvider = Provider<VpnBridge>((ref) => NativeVpnBridge());

final vpnControllerProvider =
    NotifierProvider<VpnController, VpnState>(VpnController.new);

class _LifecycleHook with WidgetsBindingObserver {
  _LifecycleHook(this.onChange);
  final void Function(AppLifecycleState) onChange;
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) => onChange(state);
}

class VpnController extends Notifier<VpnState> {
  static const _pingInterval = Duration(seconds: 10);

  Timer? _pingTimer;
  StreamSubscription<String>? _nativeStates;
  bool _disposed = false;

  @override
  VpnState build() {
    final hook = _LifecycleHook(_onLifecycle);
    WidgetsBinding.instance.addObserver(hook);
    ref.onDispose(() {
      _disposed = true;
      WidgetsBinding.instance.removeObserver(hook);
      _pingTimer?.cancel();
      _nativeStates?.cancel();
    });
    return const VpnState();
  }

  VpnBridge get _bridge => ref.read(vpnBridgeProvider);

  /// Фон: таймер пинга ОСТАНАВЛИВАЕТСЯ полностью (никаких пробуждений CPU).
  /// Возврат: один мгновенный замер + перезапуск таймера.
  /// ВАЖНО: сам туннель живёт в нативном Foreground Service и не зависит от UI.
  void _onLifecycle(AppLifecycleState s) {
    switch (s) {
      case AppLifecycleState.resumed:
        if (state.status == VpnStatus.connected) _startPing(immediate: true);
      case AppLifecycleState.inactive:
        break; // шторка/диалог: кратковременно, не трогаем
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        _stopPing();
    }
  }

  void _startPing({bool immediate = false}) {
    _pingTimer?.cancel();
    if (immediate) unawaited(_pingOnce());
    _pingTimer = Timer.periodic(_pingInterval, (_) => unawaited(_pingOnce()));
  }

  void _stopPing() {
    _pingTimer?.cancel();
    _pingTimer = null;
  }

  Future<void> _pingOnce() async {
    try {
      final p = await _bridge.measurePing();
      if (!_disposed && state.status == VpnStatus.connected) {
        state = state.copyWith(pingMs: p);
      }
    } catch (_) {/* пинг — не критичен, ошибки не логируем */}
  }

  Future<void> toggle() async {
    switch (state.status) {
      case VpnStatus.handshake:
        return;
      case VpnStatus.idle:
        await _connect();
      case VpnStatus.connected:
        await _disconnect();
    }
  }

  Future<void> _connect() async {
    state = state.copyWith(status: VpnStatus.handshake, clearPing: true);
    try {
      if (_bridge is NativeVpnBridge) {
        final native = _bridge as NativeVpnBridge;
        final connected = Completer<void>();
        _nativeStates?.cancel();
        _nativeStates = native.states.listen((s) {
          if (s == 'connected' && !connected.isCompleted) connected.complete();
          if (s == 'error' && !connected.isCompleted) connected.completeError(StateError('native_connect_failed'));
        });
        await native.connect('{}');
        await connected.future.timeout(const Duration(seconds: 20));
      } else {
        await _bridge.connect('{}');
      }
      if (_disposed) return;
      final ping = await _bridge.measurePing();
      state = state.copyWith(status: VpnStatus.connected, pingMs: ping >= 0 ? ping : null);
    } catch (_) {
      if (!_disposed) state = state.copyWith(status: VpnStatus.idle);
      return;
    }
    if (!_disposed &&
        WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
      _startPing();
    }
  }

  Future<void> _disconnect() async {
    _stopPing();
    await _bridge.disconnect();
    if (!_disposed) state = state.copyWith(status: VpnStatus.idle, clearPing: true);
  }
}
