import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'state/theme_engine.dart';
import 'ui/screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  runApp(const ProviderScope(child: LumenApp()));
}

class LumenApp extends StatelessWidget {
  const LumenApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Host стоит ВЫШЕ MaterialApp: тема морфится, а дерево виджетов не пересоздаётся.
    return LiquidThemeHost(
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Lumen',
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          splashFactory: NoSplash.splashFactory,
          highlightColor: Colors.transparent,
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
