import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../state/theme_engine.dart';
import '../../state/vpn_controller.dart';
import '../design/liquid_background.dart';
import '../design/liquid_glass.dart';
import '../design/liquid_theme.dart';
import '../widgets/liquid_connect_button.dart';
import '../widgets/ping_indicator.dart';
import '../widgets/status_badge.dart';
import '../widgets/theme_switcher.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.liquid;
    final vpn = ref.watch(vpnControllerProvider);

    final accent = switch (vpn.status) {
      VpnStatus.idle => t.accentIdle,
      VpnStatus.handshake => t.accentHandshake,
      VpnStatus.connected => t.accentConnected,
    };
    final hint = switch (vpn.status) {
      VpnStatus.idle => 'Нажмите, чтобы подключиться',
      VpnStatus.handshake => 'Устанавливаем Reality-соединение',
      VpnStatus.connected => 'Нажмите, чтобы отключить',
    };

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: t.isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Positioned.fill(
              child: TweenAnimationBuilder<Color?>(
                tween: ColorTween(end: accent),
                duration: const Duration(milliseconds: 800),
                curve: Curves.easeOutCubic,
                builder: (_, c, __) => LiquidBackground(accent: c ?? accent),
              ),
            ),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Text(
                          'Lumen',
                          style: TextStyle(
                            color: t.textPrimary,
                            fontSize: 28,
                            fontWeight: FontWeight.w700,
                            letterSpacing: -.8,
                          ),
                        ),
                        const Spacer(),
                        StatusBadge(status: vpn.status),
                      ],
                    ),
                    const SizedBox(height: LiquidSpace.md),
                    _ServerPill(vpn: vpn),
                    Expanded(
                      child: Center(
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: LiquidConnectButton(
                            status: vpn.status,
                            onPressed: () =>
                                ref.read(vpnControllerProvider.notifier).toggle(),
                          ),
                        ),
                      ),
                    ),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 380),
                      switchInCurve: Curves.easeOutCubic,
                      child: Text(
                        hint,
                        key: ValueKey(hint),
                        style: TextStyle(color: t.textSecondary, fontSize: 14),
                      ),
                    ),
                    const SizedBox(height: LiquidSpace.lg),
                    Row(
                      children: [
                        Expanded(
                          child: _StatCard(
                            label: 'Пинг',
                            child: PingIndicator(pingMs: vpn.pingMs),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _StatCard(
                            label: 'Протокол',
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  vpn.protocol,
                                  style: TextStyle(
                                    color: t.textPrimary,
                                    fontSize: 30,
                                    fontWeight: FontWeight.w700,
                                    height: 1,
                                    letterSpacing: -.8,
                                  ),
                                ),
                              ],
                            ),
                            footer: vpn.transport,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: LiquidSpace.lg),
                    const ThemeSwitcher(),
                    const SizedBox(height: LiquidSpace.md),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ServerPill extends StatelessWidget {
  const _ServerPill({required this.vpn});
  final VpnState vpn;

  @override
  Widget build(BuildContext context) {
    final t = context.liquid;
    return LiquidGlass(
      radius: 22,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Text(vpn.flag, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(vpn.serverName,
                    style: TextStyle(
                        color: t.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600)),
                Text('Выбранный сервер',
                    style: TextStyle(color: t.textSecondary, fontSize: 12.5)),
              ],
            ),
          ),
          Icon(Icons.chevron_right_rounded, color: t.textSecondary),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.label, required this.child, this.footer});
  final String label;
  final Widget child;
  final String? footer;

  @override
  Widget build(BuildContext context) {
    final t = context.liquid;
    return LiquidGlass(
      radius: 24,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: t.textSecondary, fontSize: 13)),
          const SizedBox(height: 10),
          SizedBox(height: 32, child: Align(alignment: Alignment.bottomLeft, child: child)),
          if (footer != null) ...[
            const SizedBox(height: 6),
            Text(footer!,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: t.textSecondary, fontSize: 12.5)),
          ],
        ],
      ),
    );
  }
}
