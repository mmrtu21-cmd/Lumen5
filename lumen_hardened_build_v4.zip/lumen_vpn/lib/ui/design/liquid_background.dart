import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../state/theme_engine.dart';
import 'liquid_theme.dart';

/// Живой фон: градиент + два медленно дрейфующих световых пятна
/// + мягкое свечение статуса. Цикл 36 с, кратные частоты -> бесшовный loop.
class LiquidBackground extends StatefulWidget {
  const LiquidBackground({super.key, required this.accent});
  final Color accent;

  @override
  State<LiquidBackground> createState() => _LiquidBackgroundState();
}

class _LiquidBackgroundState extends State<LiquidBackground>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 36))
        ..repeat();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    switch (s) {
      case AppLifecycleState.resumed:
        if (!_c.isAnimating) _c.repeat();
      case AppLifecycleState.inactive:
        break;
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        _c.stop();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: CustomPaint(
        size: Size.infinite,
        painter: _BgPainter(
          theme: context.liquid,
          accent: widget.accent,
          anim: _c,
        ),
      ),
    );
  }
}

class _BgPainter extends CustomPainter {
  _BgPainter({required this.theme, required this.accent, required this.anim})
      : super(repaint: anim);

  final LiquidTheme theme;
  final Color accent;
  final Animation<double> anim;

  void _blob(Canvas canvas, Offset c, double r, Color color) {
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = RadialGradient(
          colors: [color, color.withValues(alpha: 0)],
        ).createShader(Rect.fromCircle(center: c, radius: r)),
    );
  }

  @override
  void paint(Canvas canvas, Size s) {
    final rect = Offset.zero & s;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [theme.bgTop, theme.bgBottom],
        ).createShader(rect),
    );

    final t = anim.value * 2 * math.pi;
    _blob(
      canvas,
      Offset(s.width * (0.2 + 0.12 * math.sin(t)),
          s.height * (0.18 + 0.06 * math.cos(t * 2))),
      s.width * 0.9,
      theme.blobA,
    );
    _blob(
      canvas,
      Offset(s.width * (0.85 + 0.10 * math.cos(t)),
          s.height * (0.72 + 0.07 * math.sin(t * 3))),
      s.width * 0.95,
      theme.blobB,
    );
    _blob(
      canvas,
      Offset(s.width / 2, s.height * 0.46),
      s.width * 0.9,
      accent.withValues(alpha: theme.isDark ? 0.14 : 0.18),
    );
  }

  @override
  bool shouldRepaint(_BgPainter o) => o.theme != theme || o.accent != accent;
}
