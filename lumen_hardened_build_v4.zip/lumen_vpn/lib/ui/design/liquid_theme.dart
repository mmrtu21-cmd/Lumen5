import 'dart:ui' show lerpDouble;

import 'package:flutter/foundation.dart';
import 'package:flutter/painting.dart';

/// Токены раскладки.
abstract final class LiquidSpace {
  static const double xs = 6, sm = 10, md = 16, lg = 24, xl = 32;
}

abstract final class LiquidRadius {
  static const double card = 26, pill = 999;
}

enum LiquidThemeId { deepOled, frostedTitanium, midnightAurora, frostedLight }

/// Полный набор токенов темы. Все поля интерполируются -> плавный морфинг.
@immutable
class LiquidTheme {
  const LiquidTheme({
    required this.name,
    required this.isDark,
    required this.bgTop,
    required this.bgBottom,
    required this.blobA,
    required this.blobB,
    required this.glassFill,
    required this.glassHighlight,
    required this.edgeLight,
    required this.edgeDim,
    required this.textPrimary,
    required this.textSecondary,
    required this.shadow,
    required this.accentIdle,
    required this.accentHandshake,
    required this.accentConnected,
    required this.blurSigma,
  });

  final String name;
  final bool isDark;

  // Фон
  final Color bgTop, bgBottom, blobA, blobB;

  // Стекло: заливка, блик верхней грани, ультратонкая кромка (свет / тень)
  final Color glassFill, glassHighlight, edgeLight, edgeDim;

  final Color textPrimary, textSecondary, shadow;

  // Статусные акценты (Idle -> Handshake -> Connected)
  final Color accentIdle, accentHandshake, accentConnected;

  final double blurSigma;

  LiquidTheme lerp(LiquidTheme o, double t) {
    Color c(Color a, Color b) => Color.lerp(a, b, t)!;
    return LiquidTheme(
      name: t < .5 ? name : o.name,
      isDark: t < .5 ? isDark : o.isDark,
      bgTop: c(bgTop, o.bgTop),
      bgBottom: c(bgBottom, o.bgBottom),
      blobA: c(blobA, o.blobA),
      blobB: c(blobB, o.blobB),
      glassFill: c(glassFill, o.glassFill),
      glassHighlight: c(glassHighlight, o.glassHighlight),
      edgeLight: c(edgeLight, o.edgeLight),
      edgeDim: c(edgeDim, o.edgeDim),
      textPrimary: c(textPrimary, o.textPrimary),
      textSecondary: c(textSecondary, o.textSecondary),
      shadow: c(shadow, o.shadow),
      accentIdle: c(accentIdle, o.accentIdle),
      accentHandshake: c(accentHandshake, o.accentHandshake),
      accentConnected: c(accentConnected, o.accentConnected),
      blurSigma: lerpDouble(blurSigma, o.blurSigma, t)!,
    );
  }
}

abstract final class LiquidThemes {
  static LiquidTheme of(LiquidThemeId id) => switch (id) {
        LiquidThemeId.deepOled => deepOled,
        LiquidThemeId.frostedTitanium => frostedTitanium,
        LiquidThemeId.midnightAurora => midnightAurora,
        LiquidThemeId.frostedLight => frostedLight,
      };

  /// Абсолютный чёрный для OLED: фон #000, стекло едва заметно.
  static const deepOled = LiquidTheme(
    name: 'Deep OLED',
    isDark: true,
    bgTop: Color(0xFF000000),
    bgBottom: Color(0xFF000000),
    blobA: Color(0x261E6BFF),
    blobB: Color(0x1A8E5CFF),
    glassFill: Color(0x0DFFFFFF),
    glassHighlight: Color(0x1AFFFFFF),
    edgeLight: Color(0xB3FFFFFF),
    edgeDim: Color(0x14FFFFFF),
    textPrimary: Color(0xFFFFFFFF),
    textSecondary: Color(0x99EBEBF5),
    shadow: Color(0x99000000),
    accentIdle: Color(0xFF8E9BFF),
    accentHandshake: Color(0xFFFFB020),
    accentConnected: Color(0xFF30D158),
    blurSigma: 28,
  );

  static const frostedTitanium = LiquidTheme(
    name: 'Frosted Titanium',
    isDark: true,
    bgTop: Color(0xFF3A3B3E),
    bgBottom: Color(0xFF1C1D20),
    blobA: Color(0x44C9C2B8),
    blobB: Color(0x336C7A89),
    glassFill: Color(0x1AFFFFFF),
    glassHighlight: Color(0x33F2F0EA),
    edgeLight: Color(0xCCF5F3EE),
    edgeDim: Color(0x22FFFFFF),
    textPrimary: Color(0xFFF4F2EE),
    textSecondary: Color(0xAAD6D3CC),
    shadow: Color(0x80000000),
    accentIdle: Color(0xFFC9CDD3),
    accentHandshake: Color(0xFFF2C57C),
    accentConnected: Color(0xFF8AE6C4),
    blurSigma: 32,
  );

  static const midnightAurora = LiquidTheme(
    name: 'Midnight Aurora',
    isDark: true,
    bgTop: Color(0xFF0A0524),
    bgBottom: Color(0xFF160A44),
    blobA: Color(0x886C3BFF),
    blobB: Color(0x6600D9FF),
    glassFill: Color(0x14FFFFFF),
    glassHighlight: Color(0x2EB8A6FF),
    edgeLight: Color(0xBFD9CFFF),
    edgeDim: Color(0x1FFFFFFF),
    textPrimary: Color(0xFFFFFFFF),
    textSecondary: Color(0xB3C9C0F5),
    shadow: Color(0x99050218),
    accentIdle: Color(0xFF9A86FF),
    accentHandshake: Color(0xFFFF4FD8),
    accentConnected: Color(0xFF2DF5C0),
    blurSigma: 30,
  );

  static const frostedLight = LiquidTheme(
    name: 'Frosted Light',
    isDark: false,
    bgTop: Color(0xFFF5F7FB),
    bgBottom: Color(0xFFDDE3EF),
    blobA: Color(0x66A9C4FF),
    blobB: Color(0x55FFC8E6),
    glassFill: Color(0x8CFFFFFF),
    glassHighlight: Color(0xCCFFFFFF),
    edgeLight: Color(0xFFFFFFFF),
    edgeDim: Color(0x1A000000),
    textPrimary: Color(0xFF0B0C10),
    textSecondary: Color(0x99202433),
    shadow: Color(0x33203050),
    accentIdle: Color(0xFF7C849B),
    accentHandshake: Color(0xFFFF9F0A),
    accentConnected: Color(0xFF12B76A),
    blurSigma: 24,
  );
}
