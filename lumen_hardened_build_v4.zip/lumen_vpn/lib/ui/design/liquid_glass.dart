import 'dart:ui';

import 'package:flutter/material.dart';

import '../../state/theme_engine.dart';
import 'liquid_theme.dart';

/// Многослойное матовое стекло:
/// 1) внешняя тень (только снаружи формы, чтобы не грязнить стекло)
/// 2) BackdropFilter blur
/// 3) диагональная заливка (блик -> тело)
/// 4) ультратонкая кромка: свет сверху-слева, тень снизу-справа
class LiquidGlass extends StatelessWidget {
  const LiquidGlass({
    super.key,
    required this.child,
    this.radius = LiquidRadius.card,
    this.padding = const EdgeInsets.all(LiquidSpace.md),
    this.blurMultiplier = 1,
  });

  final Widget child;
  final double radius;
  final EdgeInsetsGeometry padding;
  final double blurMultiplier;

  @override
  Widget build(BuildContext context) {
    final t = context.liquid;
    final br = BorderRadius.circular(radius);
    final sigma = t.blurSigma * blurMultiplier;

    return RepaintBoundary(
      child: CustomPaint(
        painter: _ShadowPainter(radius: radius, color: t.shadow),
        child: ClipRRect(
          borderRadius: br,
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: sigma,
              sigmaY: sigma,
              tileMode: TileMode.mirror,
            ),
            child: CustomPaint(
              foregroundPainter: _EdgePainter(
                radius: radius,
                light: t.edgeLight,
                dim: t.edgeDim,
              ),
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [t.glassHighlight, t.glassFill],
                  ),
                ),
                child: Padding(padding: padding, child: child),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ShadowPainter extends CustomPainter {
  _ShadowPainter({required this.radius, required this.color});
  final double radius;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final rrect = RRect.fromRectAndRadius(
      Offset.zero & size,
      Radius.circular(radius),
    );
    final outer = Path()
      ..addRect(Rect.fromLTWH(-120, -120, size.width + 240, size.height + 300));
    final hole = Path()..addRRect(rrect);
    canvas.save();
    canvas.clipPath(Path.combine(PathOperation.difference, outer, hole));
    canvas.drawRRect(
      rrect.shift(const Offset(0, 14)).deflate(6),
      Paint()
        ..color = color
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(_ShadowPainter o) => o.color != color || o.radius != radius;
}

class _EdgePainter extends CustomPainter {
  _EdgePainter({required this.radius, required this.light, required this.dim});
  final double radius;
  final Color light, dim;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = (Offset.zero & size).deflate(0.5);
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius - 0.5));
    canvas.drawRRect(
      rrect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [light, dim, dim, light.withValues(alpha: light.a * .45)],
          stops: const [0, .38, .68, 1],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(_EdgePainter o) =>
      o.light != light || o.dim != dim || o.radius != radius;
}
