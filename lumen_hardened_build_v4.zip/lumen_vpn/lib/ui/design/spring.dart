import 'package:flutter/widgets.dart';
import 'package:flutter/physics.dart';

/// Физика интерфейса. ζ = damping / (2·√(stiffness·mass)).
abstract final class LiquidSprings {
  /// ζ≈0.75 — нажатие: мгновенный отклик, лёгкий овершут.
  static const snappy = SpringDescription(mass: 1, stiffness: 520, damping: 34);

  /// ζ≈0.92 — состояния, цвета, счётчики: почти без отскока.
  static const smooth = SpringDescription(mass: 1, stiffness: 170, damping: 24);

  /// ζ≈0.56 — «отпускание» кнопки: заметная упругость.
  static const bouncy = SpringDescription(mass: 1, stiffness: 320, damping: 20);

  /// ζ≈1.05 — морфинг темы: без овершута, шёлковая протяжка.
  static const morph = SpringDescription(mass: 1, stiffness: 110, damping: 22);
}

extension SpringController on AnimationController {
  /// Запускает пружину к [target], СОХРАНЯЯ текущую скорость.
  /// Поэтому анимацию можно прерывать в любой момент без рывка.
  /// Требует AnimationController.unbounded (иначе овершут будет обрезан).
  TickerFuture springTo(
    double target,
    SpringDescription spring, {
    double? velocity,
  }) {
    return animateWith(
      SpringSimulation(spring, value, target, velocity ?? this.velocity),
    );
  }
}

/// Неявная пружинная анимация числа (аналог TweenAnimationBuilder, но на физике).
class SpringBuilder extends StatefulWidget {
  const SpringBuilder({
    super.key,
    required this.value,
    required this.builder,
    this.spring = LiquidSprings.smooth,
    this.child,
  });

  final double value;
  final SpringDescription spring;
  final Widget Function(BuildContext context, double value, Widget? child)
      builder;
  final Widget? child;

  @override
  State<SpringBuilder> createState() => _SpringBuilderState();
}

class _SpringBuilderState extends State<SpringBuilder>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController.unbounded(vsync: this, value: widget.value);

  @override
  void didUpdateWidget(SpringBuilder old) {
    super.didUpdateWidget(old);
    if (old.value != widget.value) _c.springTo(widget.value, widget.spring);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (ctx, child) => widget.builder(ctx, _c.value, child),
    );
  }
}
