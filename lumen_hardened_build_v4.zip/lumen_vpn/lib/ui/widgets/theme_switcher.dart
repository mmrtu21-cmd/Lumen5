import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../state/theme_engine.dart';
import '../design/liquid_glass.dart';
import '../design/liquid_theme.dart';
import '../design/spring.dart';

class ThemeSwitcher extends ConsumerWidget {
  const ThemeSwitcher({super.key});

  static const _swatches = {
    LiquidThemeId.deepOled: [Color(0xFF000000), Color(0xFF3A3A3C)],
    LiquidThemeId.frostedTitanium: [Color(0xFFD8D6D0), Color(0xFF6F6D69)],
    LiquidThemeId.midnightAurora: [Color(0xFF7B5CFF), Color(0xFF00E5FF)],
    LiquidThemeId.frostedLight: [Color(0xFFFFFFFF), Color(0xFFC9D3E6)],
  };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(themeEngineProvider);
    final t = context.liquid;

    return LiquidGlass(
      radius: LiquidRadius.pill,
      blurMultiplier: .7,
      padding: const EdgeInsets.all(8),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (final id in LiquidThemeId.values)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5),
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => ref.read(themeEngineProvider.notifier).select(id),
                child: Semantics(
                  button: true,
                  selected: id == selected,
                  label: LiquidThemes.of(id).name,
                  child: SpringBuilder(
                    value: id == selected ? 1 : 0,
                    spring: LiquidSprings.bouncy,
                    builder: (_, v, __) => Transform.scale(
                      scale: 1 + .14 * v,
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: _swatches[id]!,
                          ),
                          border: Border.all(
                            color: Color.lerp(
                              t.edgeDim,
                              t.textPrimary,
                              v.clamp(0.0, 1.0),
                            )!,
                            width: 1 + v.clamp(0.0, 1.0),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
