import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../../state/theme_engine.dart';
import '../../state/vpn_controller.dart';
import '../design/liquid_theme.dart';
import '../design/spring.dart';

// ───────────────────────── «настроение» кнопки ─────────────────────────
// Один пружинный параметр mood: 0 = Idle, 1 = Handshake, 2 = Connected.
// Из него выводятся цвет, амплитуда и скорость дыхания — всё меняется
// согласованно и без скачков.

double _by(double m, double i, double h, double c) {
  final x = clampDouble(m, 0, 2);
  return x <= 1 ? lerpDouble(i, h, x)! : lerpDouble(h, c, x - 1)!;
}

Color _accentFor(LiquidTheme t, double m) {
  final x = clampDouble(m, 0, 2);
  return x <= 1
      ? Color.lerp(t.accentIdle, t.accentHandshake, x)!
      : Color.lerp(t.accentHandshake, t.accentConnected, x - 1)!;
}

double _speed(double m) => _by(m, 0.20, 0.95, 0.30); // циклов в секунду
double _amp(double m) => _by(m, 0.55, 1.0, 0.80);

/// Органическое дыхание: две несоизмеримые синусоиды (золотое сечение)
/// + smoothstep -> никогда не повторяется «механически».
double _breath(double cycles) {
  final a = math.sin(cycles * 2 * math.pi);
  final b = math.sin(cycles * 2 * math.pi * 0.618 + 1.3);
  final v = clampDouble(0.5 + 0.5 * (0.65 * a + 0.35 * b), 0, 1);
  return v * v * (3 - 2 * v);
}

double _moodFor(VpnStatus s) => switch (s) {
      VpnStatus.idle => 0,
      VpnStatus.handshake => 1,
      VpnStatus.connected => 2,
    };

class LiquidConnectButton extends StatefulWidget {
  const LiquidConnectButton({
    super.key,
    required this.status,
    required this.onPressed,
    this.size = 200,
  });

  final VpnStatus status;
  final VoidCallback onPressed;

  /// Диаметр стеклянной сферы. Весь виджет занимает size * 1.9 (место под свечение).
  final double size;

  @override
  State<LiquidConnectButton> createState() => _LiquidConnectButtonState();
}

class _LiquidConnectButtonState extends State<LiquidConnectButton>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _mood =
      AnimationController.unbounded(vsync: this, value: _moodFor(widget.status));
  late final AnimationController _press =
      AnimationController.unbounded(vsync: this);
  late final AnimationController _ripple = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1300),
  );
  final ValueNotifier<double> _phase = ValueNotifier(0);
  late final Ticker _ticker = createTicker(_tick);
  Duration _last = Duration.zero;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _ticker.start();
  }

  /// Фон: тикер дыхания и все пружины останавливаются, состояние «схлопывается»
  /// в целевое. Возврат: _last сбрасывается, иначе первый dt был бы огромным.
  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    switch (s) {
      case AppLifecycleState.resumed:
        if (!_ticker.isActive) {
          _last = Duration.zero;
          _ticker.start();
        }
      case AppLifecycleState.inactive:
        break;
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        _ticker.stop();
        _mood
          ..stop()
          ..value = _moodFor(widget.status);
        _press
          ..stop()
          ..value = 0;
        _ripple
          ..stop()
          ..value = 0;
    }
  }

  /// Фаза дыхания ИНТЕГРИРУЕТСЯ (phase += dt * speed), а не берётся как t * speed.
  /// Поэтому смена скорости (Idle -> Handshake) не вызывает скачка фазы.
  void _tick(Duration elapsed) {
    var dt = (elapsed - _last).inMicroseconds / 1e6;
    _last = elapsed;
    if (dt <= 0 || dt > 0.1) dt = 1 / 60;
    _phase.value += dt * _speed(_mood.value);
  }

  @override
  void didUpdateWidget(LiquidConnectButton old) {
    super.didUpdateWidget(old);
    if (old.status == widget.status) return;
    _mood.springTo(_moodFor(widget.status), LiquidSprings.smooth);
    switch (widget.status) {
      case VpnStatus.handshake:
        break;
      case VpnStatus.connected:
        HapticFeedback.heavyImpact();
        _ripple.forward(from: 0);
      case VpnStatus.idle:
        HapticFeedback.lightImpact();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker.dispose();
    _mood.dispose();
    _press.dispose();
    _ripple.dispose();
    _phase.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = context.liquid;
    final s = widget.size;

    return Semantics(
      button: true,
      label: switch (widget.status) {
        VpnStatus.idle => 'Подключить VPN',
        VpnStatus.handshake => 'Подключение',
        VpnStatus.connected => 'Отключить VPN',
      },
      child: SizedBox.square(
        dimension: s * 1.9,
        child: Stack(
          alignment: Alignment.center,
          clipBehavior: Clip.none,
          children: [
            // Слой 1: объёмное свечение за сферой
            Positioned.fill(
              child: IgnorePointer(
                child: RepaintBoundary(
                  child: CustomPaint(
                    painter: _GlowPainter(
                      theme: t,
                      mood: _mood,
                      phase: _phase,
                      press: _press,
                      ripple: _ripple,
                      orbRadius: s / 2,
                    ),
                  ),
                ),
              ),
            ),
            // Слой 2: стеклянная сфера (жесты + масштаб на пружине)
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: (_) {
                HapticFeedback.selectionClick();
                _press.springTo(1, LiquidSprings.snappy);
              },
              onTapUp: (_) => _press.springTo(0, LiquidSprings.bouncy),
              onTapCancel: () => _press.springTo(0, LiquidSprings.bouncy),
              onTap: widget.onPressed,
              child: AnimatedBuilder(
                animation: _press,
                builder: (_, child) => Transform.scale(
                  scale: 1 - 0.07 * _press.value,
                  child: child,
                ),
                child: SizedBox.square(
                  dimension: s,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned.fill(
                        child: ClipOval(
                          child: BackdropFilter(
                            filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
                            child: CustomPaint(
                              painter: _CorePainter(
                                theme: t,
                                mood: _mood,
                                phase: _phase,
                                press: _press,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _RingPainter(
                              theme: t,
                              mood: _mood,
                              phase: _phase,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────── painters ───────────────────────────────

class _GlowPainter extends CustomPainter {
  _GlowPainter({
    required this.theme,
    required this.mood,
    required this.phase,
    required this.press,
    required this.ripple,
    required this.orbRadius,
  }) : super(repaint: Listenable.merge([mood, phase, press, ripple]));

  final LiquidTheme theme;
  final ValueListenable<double> mood, phase, press, ripple;
  final double orbRadius;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final m = mood.value;
    final accent = _accentFor(theme, m);
    final g = _breath(phase.value) * _amp(m);
    final p = clampDouble(press.value, 0, 1.2);

    final radius = orbRadius * (1.45 + 0.35 * g + 0.10 * p);
    final a = clampDouble(0.20 + 0.38 * g + 0.12 * p, 0, 1);
    canvas.drawCircle(
      c,
      radius,
      Paint()
        ..shader = RadialGradient(
          colors: [
            accent.withValues(alpha: a),
            accent.withValues(alpha: a * .35),
            accent.withValues(alpha: 0),
          ],
          stops: const [0, .55, 1],
        ).createShader(Rect.fromCircle(center: c, radius: radius)),
    );

    // Ударная волна при успешном подключении (easeOutCubic)
    final rv = ripple.value;
    if (rv > 0 && rv < 1) {
      final e = Curves.easeOutCubic.transform(rv);
      canvas.drawCircle(
        c,
        orbRadius * (1 + 0.9 * e),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.6 + 3.0 * (1 - e)
          ..color = theme.accentConnected.withValues(alpha: 0.55 * (1 - e)),
      );
    }
  }

  @override
  bool shouldRepaint(_GlowPainter o) =>
      o.theme != theme || o.orbRadius != orbRadius;
}

class _CorePainter extends CustomPainter {
  _CorePainter({
    required this.theme,
    required this.mood,
    required this.phase,
    required this.press,
  }) : super(repaint: Listenable.merge([mood, phase, press]));

  final LiquidTheme theme;
  final ValueListenable<double> mood, phase, press;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final rect = Rect.fromCircle(center: c, radius: r);
    final m = mood.value;
    final accent = _accentFor(theme, m);
    final glow = _breath(phase.value) * _amp(m);
    final p = clampDouble(press.value, 0, 1);

    // Тело стекла, подсветка из левого-верхнего угла
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.3, -0.5),
          radius: 1.15,
          colors: [
            Color.lerp(Colors.white, accent, .45)!.withValues(alpha: .50),
            accent.withValues(alpha: .20 + .10 * glow),
            accent.withValues(alpha: .05),
          ],
          stops: const [0, .55, 1],
        ).createShader(rect),
    );

    // Дышащий внутренний свет по краю сферы
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = RadialGradient(
          colors: [
            accent.withValues(alpha: 0),
            accent.withValues(alpha: 0),
            accent.withValues(alpha: .15 + .45 * glow),
          ],
          stops: const [0, .72, 1],
        ).createShader(rect),
    );

    // Зеркальный блик верхней линзы
    final hl = Rect.fromCenter(
      center: c.translate(0, -r * .52),
      width: r * 1.1,
      height: r * .55,
    );
    canvas.drawOval(
      hl,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Colors.white.withValues(alpha: .55),
            Colors.white.withValues(alpha: 0),
          ],
        ).createShader(hl),
    );

    // Отклик на нажатие
    if (p > 0.01) {
      canvas.drawCircle(c, r, Paint()..color = Colors.white.withValues(alpha: .10 * p));
    }

    // Ультратонкая кромка
    canvas.drawCircle(
      c,
      r - 0.7,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [theme.edgeLight, theme.edgeDim, theme.edgeDim, theme.edgeLight.withValues(alpha: theme.edgeLight.a * .5)],
          stops: const [0, .4, .7, 1],
        ).createShader(rect),
    );

    // Глиф питания
    final hs = clampDouble(1 - (m - 1).abs(), 0, 1);
    final iconColor = Color.lerp(
      theme.textPrimary.withValues(alpha: .88),
      accent,
      clampDouble(m, 0, 2) / 2 * .85,
    )!
        .withValues(alpha: 1 - .45 * hs);
    final gr = r * .26;
    final arc = Rect.fromCircle(center: c, radius: gr);
    const start = -math.pi / 2 + 0.62;
    const sweep = 2 * math.pi - 1.24;
    final line = Path()
      ..moveTo(c.dx, c.dy - gr * 1.18)
      ..lineTo(c.dx, c.dy - gr * 0.12);

    final glyph = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = r * .06;

    final halo = Paint.from(glyph)
      ..color = accent.withValues(alpha: .55 * glow)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9);
    canvas.drawArc(arc, start, sweep, false, halo);
    canvas.drawPath(line, halo);

    glyph.color = iconColor;
    canvas.drawArc(arc, start, sweep, false, glyph);
    canvas.drawPath(line, glyph);
  }

  @override
  bool shouldRepaint(_CorePainter o) => o.theme != theme;
}

class _RingPainter extends CustomPainter {
  _RingPainter({required this.theme, required this.mood, required this.phase})
      : super(repaint: Listenable.merge([mood, phase]));

  final LiquidTheme theme;
  final ValueListenable<double> mood, phase;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final radius = size.width / 2 + 9;
    final rect = Rect.fromCircle(center: c, radius: radius);
    final m = mood.value;
    final accent = _accentFor(theme, m);
    final b = _breath(phase.value);

    canvas.drawCircle(
      c,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = accent.withValues(alpha: .16),
    );

    // Handshake: комета с хвостом, скорость вращения следует за пружиной mood
    final hs = clampDouble(1 - (m - 1).abs(), 0, 1);
    if (hs > 0.01) {
      final spin = phase.value * 2 * math.pi;
      canvas.drawCircle(
        c,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3.2
          ..shader = SweepGradient(
            colors: [
              accent.withValues(alpha: 0),
              accent.withValues(alpha: .95 * hs),
            ],
            transform: GradientRotation(spin),
          ).createShader(rect),
      );
      canvas.drawCircle(
        c + Offset(math.cos(spin), math.sin(spin)) * radius,
        3.4,
        Paint()..color = accent.withValues(alpha: hs),
      );
    }

    // Connected: замкнутое «дышащее» кольцо
    final ca = clampDouble(m - 1, 0, 1);
    if (ca > 0.01) {
      canvas.drawCircle(
        c,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.2
          ..color = accent.withValues(alpha: (.35 + .40 * b) * ca),
      );
    }
  }

  @override
  bool shouldRepaint(_RingPainter o) => o.theme != theme;
}
