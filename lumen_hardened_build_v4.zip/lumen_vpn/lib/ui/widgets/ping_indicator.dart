import 'package:flutter/material.dart';

import '../../state/theme_engine.dart';
import '../design/spring.dart';

/// Пинг: число «перетекает» пружиной, 4 столбика сигнала пружинят по очереди.
class PingIndicator extends StatelessWidget {
  const PingIndicator({super.key, required this.pingMs});
  final int? pingMs;

  static const _bars = [8.0, 12.0, 16.0, 20.0];

  int get _active {
    final p = pingMs;
    if (p == null) return 0;
    if (p < 60) return 4;
    if (p < 120) return 3;
    if (p < 200) return 2;
    return 1;
  }

  @override
  Widget build(BuildContext context) {
    final t = context.liquid;
    final p = pingMs;
    final color = p == null
        ? t.textSecondary
        : p < 120
            ? t.accentConnected
            : p < 200
                ? t.accentHandshake
                : const Color(0xFFFF453A);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        SpringBuilder(
          value: (p ?? 0).toDouble(),
          builder: (_, v, __) => Text(
            p == null ? '—' : '${v.clamp(0, 999).round()}',
            style: TextStyle(
              color: t.textPrimary,
              fontSize: 30,
              fontWeight: FontWeight.w700,
              height: 1,
              letterSpacing: -.8,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
        ),
        const SizedBox(width: 4),
        Padding(
          padding: const EdgeInsets.only(bottom: 3),
          child: Text('мс',
              style: TextStyle(color: t.textSecondary, fontSize: 13)),
        ),
        const Spacer(),
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            for (var i = 0; i < _bars.length; i++)
              Padding(
                padding: const EdgeInsets.only(left: 3),
                child: SpringBuilder(
                  value: i < _active ? 1 : 0,
                  spring: LiquidSprings.bouncy,
                  builder: (_, v, __) => Container(
                    width: 4.5,
                    height: _bars[i] * (.7 + .3 * v.clamp(0.0, 1.3)),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(2),
                      color: Color.lerp(
                        t.textSecondary.withValues(alpha: .25),
                        color,
                        v.clamp(0.0, 1.0),
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}
