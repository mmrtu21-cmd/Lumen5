import 'package:flutter/material.dart';

import '../../state/theme_engine.dart';
import '../../state/vpn_controller.dart';
import '../design/liquid_glass.dart';
import '../design/liquid_theme.dart';

class StatusBadge extends StatelessWidget {
  const StatusBadge({super.key, required this.status});
  final VpnStatus status;

  @override
  Widget build(BuildContext context) {
    final t = context.liquid;
    final (label, color) = switch (status) {
      VpnStatus.idle => ('Не защищено', t.accentIdle),
      VpnStatus.handshake => ('Рукопожатие…', t.accentHandshake),
      VpnStatus.connected => ('Защищено', t.accentConnected),
    };

    return LiquidGlass(
      radius: LiquidRadius.pill,
      blurMultiplier: .6,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          TweenAnimationBuilder<Color?>(
            tween: ColorTween(end: color),
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeOutCubic,
            builder: (_, c, __) => Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: c,
                boxShadow: [BoxShadow(color: c!.withValues(alpha: .8), blurRadius: 8)],
              ),
            ),
          ),
          const SizedBox(width: 8),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 380),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeInCubic,
            transitionBuilder: (child, anim) => FadeTransition(
              opacity: anim,
              child: SlideTransition(
                position: Tween(begin: const Offset(0, .35), end: Offset.zero)
                    .animate(anim),
                child: child,
              ),
            ),
            child: Text(
              label,
              key: ValueKey(status),
              style: TextStyle(
                color: t.textPrimary,
                fontSize: 14,
                fontWeight: FontWeight.w600,
                letterSpacing: -.1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
