package com.lumen.vpn.vpn

import android.content.Context
import go.Seq
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.util.concurrent.CopyOnWriteArraySet

enum class TunnelState { IDLE, HANDSHAKE, CONNECTED, RECONNECTING, WAITING_NETWORK, ERROR }

object VpnStateBus {
    @Volatile var state: TunnelState = TunnelState.IDLE; private set
    private val listeners = CopyOnWriteArraySet<(TunnelState) -> Unit>()
    fun publish(s: TunnelState) { state = s; listeners.forEach { it(s) } }
    fun subscribe(l: (TunnelState) -> Unit) = listeners.add(l)
    fun unsubscribe(l: (TunnelState) -> Unit) = listeners.remove(l)
}

object SafeLog {
    @Volatile var debuggable = false
    fun w(code: String) { if (debuggable) android.util.Log.w("Lumen", code) }
}

interface XrayCore {
    fun start(configJson: String, tunFd: Int, onExit: () -> Unit)
    fun stop()
}

object CoreFactory {
    @Volatile private var appContext: Context? = null

    fun init(context: Context) {
        val c = context.applicationContext
        appContext = c
        Seq.setContext(c)
        // The AAR reads geo assets through gomobile's asset bridge.
        Libv2ray.initCoreEnv(c.filesDir.absolutePath, "lumen")
    }

    fun newCore(onExit: () -> Unit = {}) = object : XrayCore {
        private var controller: CoreController? = null

        private val callback = object : CoreCallbackHandler {
            override fun startup(): Int {
                VpnStateBus.publish(TunnelState.CONNECTED)
                return 0
            }
            override fun shutdown(): Int {
                onExit()
                return 0
            }
            override fun onEmitStatus(code: Int, message: String): Int = 0
        }

        override fun start(configJson: String, tunFd: Int, onExit: () -> Unit) {
            controller = Libv2ray.newCoreController(callback)
            controller!!.startLoop(configJson, tunFd)
        }

        override fun stop() {
            runCatching { controller?.stopLoop() }
            controller = null
        }
    }
}
