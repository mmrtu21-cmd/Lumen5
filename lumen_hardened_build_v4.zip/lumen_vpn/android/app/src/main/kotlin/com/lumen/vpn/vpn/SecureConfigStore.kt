package com.lumen.vpn.vpn

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Конфиг (Reality pbk/sid, UUID, SOCKS-креды) хранится ТОЛЬКО зашифрованным:
 * AES-256-GCM, ключ в AndroidKeyStore (не извлекается), файл в noBackupFilesDir
 * (не попадает в бэкапы). Через Intent extras конфиг не передаётся.
 */
object SecureConfigStore {
    private const val ALIAS = "lumen_cfg_key"
    private const val FILE = "cfg.bin"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    fun save(ctx: Context, envelope: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val iv = c.iv
        val ct = c.doFinal(envelope.toByteArray(Charsets.UTF_8))
        File(ctx.noBackupFilesDir, FILE).writeBytes(byteArrayOf(iv.size.toByte()) + iv + ct)
    }

    fun load(ctx: Context): String? = try {
        val f = File(ctx.noBackupFilesDir, FILE)
        if (!f.exists()) null else {
            val raw = f.readBytes()
            val n = raw[0].toInt()
            val c = Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 1, n))
            }
            String(c.doFinal(raw, 1 + n, raw.size - 1 - n), Charsets.UTF_8)
        }
    } catch (_: Exception) { null }

    fun wipe(ctx: Context) { File(ctx.noBackupFilesDir, FILE).delete() }
}
