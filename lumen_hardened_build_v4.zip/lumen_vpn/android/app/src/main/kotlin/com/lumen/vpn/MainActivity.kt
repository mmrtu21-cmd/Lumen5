package com.lumen.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import com.lumen.vpn.vpn.LumenVpnService
import com.lumen.vpn.vpn.SecureConfigStore
import com.lumen.vpn.vpn.TunnelState
import com.lumen.vpn.vpn.VpnStateBus

class MainActivity : FlutterActivity() {
    companion object { private const val CHANNEL = "lumen/tunnel"; private const val EVENTS = "lumen/tunnel/events"; private const val REQ_VPN = 1001 }
    private var pendingEnvelope: String? = null
    private var eventSink: EventChannel.EventSink? = null

    override fun configureFlutterEngine(@NonNull engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "connect" -> {
                    val envelope = call.argument<String>("envelope")
                    if (envelope.isNullOrBlank()) { result.error("invalid_config", "empty", null); return@setMethodCallHandler }
                    SecureConfigStore.save(this, envelope)
                    val intent = VpnService.prepare(this)
                    if (intent != null) {
                        pendingEnvelope = envelope
                        startActivityForResult(intent, REQ_VPN)
                        result.success("permission_required")
                    } else {
                        startService(Intent(this, LumenVpnService::class.java))
                        result.success("started")
                    }
                }
                "disconnect" -> {
                    startService(Intent(this, LumenVpnService::class.java).setAction(LumenVpnService.ACTION_STOP))
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
        EventChannel(engine.dartExecutor.binaryMessenger, EVENTS).setStreamHandler(object : EventChannel.StreamHandler {
            private val listener: (TunnelState) -> Unit = { state -> eventSink?.success(state.name.lowercase()) }
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) { eventSink = events; VpnStateBus.subscribe(listener); events?.success(VpnStateBus.state.name.lowercase()) }
            override fun onCancel(arguments: Any?) { VpnStateBus.unsubscribe(listener); eventSink = null }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_VPN) return
        if (resultCode == Activity.RESULT_OK && pendingEnvelope != null) {
            startService(Intent(this, LumenVpnService::class.java))
        } else {
            SecureConfigStore.wipe(this)
            VpnStateBus.publish(TunnelState.IDLE)
        }
        pendingEnvelope = null
    }
}
