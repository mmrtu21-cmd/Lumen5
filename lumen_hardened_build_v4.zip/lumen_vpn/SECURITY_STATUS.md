# Security status

This is a security-hardened personal Android tunnel client, but no software can honestly be declared 100% secure.

The native path is Android VpnService -> TUN fd -> AndroidLibXrayLite/CoreController.StartLoop(config, tunFd). The old tun2socks placeholder is removed.

The CI pins the Xray Android runtime to a specific release instead of silently following an arbitrary future build.

Hardened measures include cleartext traffic disabled, Android backup disabled for app data, encrypted private config storage using Android Keystore AES-GCM, status-only notifications, native EventChannel state reporting, no `freedom` outbound in the hardened config, and a native TUN inbound instead of a local SOCKS listener.

Not proven in this environment: Flutter/Gradle compilation and physical-device TUN/network leak testing. Before relying on the build continuously, run the GitHub Actions build and test the resulting APK on the target phone, including connection-loss/reconnect behavior and Android's "block connections without VPN" setting if a strict no-leak policy is required.

The CI currently pins AndroidLibXrayLite to v26.9.9, matching the currently indexed official GitHub release. Do not silently change that pin to an unreviewed version.
