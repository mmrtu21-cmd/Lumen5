# Lumen build v0.1.0+2

Changes from the previous fixed archive:
- Bumped Android/Dart versionCode to 2 (`0.1.0+2`).
- Kept Flutter Android embedding v2 and the hardened manifest.
- Kept the pinned Xray runtime at AndroidLibXrayLite `v26.9.9`.
- CI now explicitly installs Gradle 8.9 before generating the wrapper, instead of assuming a preinstalled Gradle binary.
- CI verifies the AAR is a valid archive before building.
- CI runs the existing Dart tests before assembling the APK.
- CI uploads the release APK as `lumen-release-v0.1.0-2`.

The APK itself is produced by GitHub Actions; this archive is the updated source project/workflow.
