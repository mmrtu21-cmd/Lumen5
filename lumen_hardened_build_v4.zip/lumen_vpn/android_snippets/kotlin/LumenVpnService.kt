package com.lumen.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.PowerManager
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.min

/**
 * Always-On VPN Foreground Service.
 *
 * Принципы:
 *  1. TUN-интерфейс создаётся ОДИН РАЗ и живёт между реконнектами. Пока ядро
 *     перезапускается, пакеты приложений уходят в TUN, который никто не читает
 *     (чёрная дыра) -> окно утечки реального IP отсутствует (Dead Man's Switch).
 *  2. Все операции с ядром выполняются в одном потоке (worker) -> нет гонок.
 *  3. Каждый цикл поднятия имеет generation; устаревшие шаги самоотменяются.
 *  4. Служба исключает собственное приложение из VPN (addDisallowedApplication),
 *     поэтому сокеты ядра к серверу не заворачиваются в туннель (нет петли).
 */
class LumenVpnService : VpnService() {

    companion object {
        const val ACTION_STOP = "com.lumen.vpn.STOP"
        private const val NOTIF_ID = 7
        private const val CHANNEL = "lumen_vpn"
        private const val DEBOUNCE_MS = 1_200L
        private const val WAKELOCK_TIMEOUT_MS = 45_000L
        private const val MAX_BACKOFF_MS = 60_000L
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val generation = AtomicInteger(0)

    // Только из потока worker:
    private var tun: ParcelFileDescriptor? = null
    private var core: XrayCore? = null
    private var tunBridge: TunBridge? = null
    private var retry = 0

    @Volatile private var currentNet: Network? = null
    @Volatile private var shuttingDown = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var callbackRegistered = false
    private lateinit var cm: ConnectivityManager

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onCreate() {
        super.onCreate()
        SafeLog.debuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        cm = getSystemService(ConnectivityManager::class.java)
        ensureChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        // Сюда же попадаем при Always-On старте системой и при рестарте после OOM (intent == null).
        shuttingDown = false
        startInForeground(TunnelState.HANDSHAKE)
        registerNetworkWatcher()
        worker.execute { bringUp(initial = true) }
        return START_STICKY
    }

    /** Пользователь отключил VPN в настройках или его перехватило другое VPN. */
    override fun onRevoke() {
        shutdown()
        super.onRevoke()
    }

    override fun onDestroy() {
        shuttingDown = true
        unregisterNetworkWatcher()
        worker.shutdown() // даём дочистить уже поставленные задачи
        super.onDestroy()
    }

    // ───────────────────────── подъём / реконнект ─────────────────────────

    private fun bringUp(initial: Boolean) {
        if (shuttingDown) return
        val gen = generation.incrementAndGet()
        publish(if (initial) TunnelState.HANDSHAKE else TunnelState.RECONNECTING)
        holdWakeLock()

        val envelope = SecureConfigStore.load(this)
            ?.let { runCatching { JSONObject(it) }.getOrNull() }
            ?: return fail("no_config")

        val net = cm.activeNetwork
        if (net == null) {
            // Сети нет: TUN остаётся (чёрная дыра), ждём onAvailable.
            stopCoreStack()
            publish(TunnelState.WAITING_NETWORK)
            releaseWakeLock()
            return
        }
        currentNet = net

        try {
            if (tun == null) tun = establishTun() ?: return fail("tun")
            setUnderlyingNetworks(arrayOf(net))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                VpnStateBus.lockdownEnabled = isLockdownEnabled
            }
            stopCoreStack()
            if (gen != generation.get()) return
            startCoreStack(envelope, gen)
        } catch (t: Throwable) {
            SafeLog.w("bringup_failed:" + t.javaClass.simpleName)
            stopCoreStack()
            scheduleRetry(gen)
        }
    }

    private fun startCoreStack(envelope: JSONObject, gen: Int) {
        val xrayJson = envelope.getJSONObject("xray").toString()
        val socks = envelope.getJSONObject("socks")
        val port = socks.getInt("port")

        val c = CoreFactory.newCore { onCoreExit(gen) }
        c.start(xrayJson) { onCoreExit(gen) }
        core = c

        if (!waitForLoopbackPort(port, 4_000)) error("core_not_listening")

        val t = CoreFactory.newTun()
        t.start(tun!!.fd, port, socks.getString("user"), socks.getString("pass"))
        tunBridge = t

        if (gen != generation.get() || shuttingDown) { stopCoreStack(); return }
        retry = 0
        publish(TunnelState.CONNECTED)
        releaseWakeLock()
    }

    private fun stopCoreStack() {
        runCatching { tunBridge?.stop() }; tunBridge = null
        runCatching { core?.stop() }; core = null
    }

    private fun onCoreExit(gen: Int) {
        if (gen == generation.get() && !shuttingDown) main.post { scheduleRestart() }
    }

    /** Экспоненциальный backoff 1s,2s,4s… до 60s. Устаревшие попытки отменяются через generation. */
    private fun scheduleRetry(gen: Int) {
        if (shuttingDown) return
        val delay = min(MAX_BACKOFF_MS, 1_000L shl min(retry, 6))
        retry++
        publish(TunnelState.RECONNECTING)
        main.postDelayed({
            worker.execute { if (!shuttingDown && gen == generation.get()) bringUp(false) }
        }, delay)
    }

    // ───────────────────────── TUN ─────────────────────────

    private fun establishTun(): ParcelFileDescriptor? {
        val open = PendingIntent.getActivity(
            this, 0, packageManager.getLaunchIntentForPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = Builder()
            .setSession("Lumen")
            .setMtu(1500)
            .addAddress("10.8.0.2", 30)
            // IPv6-«приёмник»: без v6-маршрута системный IPv6-трафик идёт МИМО VPN (утечка).
            // Заворачиваем весь ::/0 в TUN; дальше он режется (Xray: rule ::/0 -> block).
            .addAddress("fd00:8::2", 126)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            // Фиктивный DNS внутри туннеля. Запросы к нему (и вообще любой порт 53)
            // перехватываются Xray (dns-out) -> DoH внутри прокси. Реальных резолверов нет.
            .addDnsServer("10.8.0.1")
            .addDisallowedApplication(packageName)
            .setConfigureIntent(open)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) b.setMetered(false)
        return b.establish()
    }

    // ───────────────────────── сеть: Dead Man's Switch ─────────────────────────

    private val restartRunnable = Runnable {
        worker.execute { if (!shuttingDown) bringUp(false) }
    }

    /** Дебаунс: Wi-Fi/LTE «флапают» пачкой событий -> один рестарт. */
    private fun scheduleRestart() {
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, DEBOUNCE_MS)
    }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            // Wi-Fi -> 4G/5G (и обратно): новая default-сеть отличается от текущей.
            if (network != currentNet) scheduleRestart()
        }

        override fun onLost(network: Network) {
            if (network != currentNet) return
            currentNet = null
            main.removeCallbacks(restartRunnable)
            generation.incrementAndGet() // отменяем всё запланированное
            publish(TunnelState.WAITING_NETWORK)
            // TUN не трогаем -> трафик в чёрной дыре. Ядро гасим, чтобы не жечь батарею.
            worker.execute { stopCoreStack() }
        }
    }

    /**
     * Приложение исключено из VPN, поэтому default-сеть для нашего процесса — физическая.
     * (Проверьте на устройстве: поведение зависит от вендора/версии Android.)
     */
    private fun registerNetworkWatcher() {
        if (callbackRegistered) return
        currentNet = cm.activeNetwork // чтобы первый onAvailable не вызвал лишний рестарт
        cm.registerDefaultNetworkCallback(netCallback, main)
        callbackRegistered = true
    }

    private fun unregisterNetworkWatcher() {
        if (!callbackRegistered) return
        runCatching { cm.unregisterNetworkCallback(netCallback) }
        callbackRegistered = false
    }

    private fun waitForLoopbackPort(port: Int, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 300) }
                return true
            } catch (_: Exception) { Thread.sleep(150) }
        }
        return false
    }

    // ───────────────────────── остановка ─────────────────────────

    private fun shutdown() {
        shuttingDown = true
        generation.incrementAndGet()
        main.removeCallbacksAndMessages(null)
        unregisterNetworkWatcher()
        worker.execute {
            stopCoreStack()
            runCatching { tun?.close() }; tun = null
            releaseWakeLock()
            main.post {
                publish(TunnelState.IDLE)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun fail(code: String) {
        SafeLog.w("fail:$code")
        releaseWakeLock()
        publish(TunnelState.ERROR)
    }

    // ───────────────────────── WakeLock (только окно реконнекта) ─────────────────────────
    // Постоянный PARTIAL_WAKE_LOCK у VPN-сервиса не нужен: активный туннель и так держит
    // радио, а вечный wakelock убивает батарею 24/7. Берём с таймаутом на рукопожатие.

    private fun holdWakeLock() {
        val wl = wakeLock ?: getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lumen:reconnect")
            .also { it.setReferenceCounted(false); wakeLock = it }
        wl.acquire(WAKELOCK_TIMEOUT_MS)
    }

    private fun releaseWakeLock() {
        wakeLock?.takeIf { it.isHeld }?.release()
    }

    // ───────────────────────── Foreground notification ─────────────────────────

    private fun publish(s: TunnelState) {
        VpnStateBus.publish(s)
        if (!shuttingDown) {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(s))
        }
    }

    private fun startInForeground(s: TunnelState) {
        val n = buildNotification(s)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun buildNotification(s: TunnelState): Notification {
        val text = when (s) {
            TunnelState.CONNECTED -> "Защищено"
            TunnelState.HANDSHAKE -> "Подключение…"
            TunnelState.RECONNECTING -> "Переподключение…"
            TunnelState.WAITING_NETWORK -> "Ожидание сети. Трафик заблокирован"
            TunnelState.ERROR -> "Ошибка. Трафик заблокирован"
            TunnelState.IDLE -> "Отключено"
        }
        val open = PendingIntent.getActivity(
            this, 0, packageManager.getLaunchIntentForPackage(packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, LumenVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock) // замените на свой монохромный ресурс
            .setContentTitle("Lumen")
            .setContentText(text) // только статус: никаких IP и имён серверов
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Отключить", stop).build())
            .build()
    }

    private fun ensureChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "VPN", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                    lockscreenVisibility = Notification.VISIBILITY_PRIVATE
                }
            )
        }
    }
}
