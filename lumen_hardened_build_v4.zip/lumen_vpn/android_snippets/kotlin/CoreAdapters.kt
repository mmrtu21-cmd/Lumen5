package com.lumen.vpn.vpn

import java.util.concurrent.CopyOnWriteArraySet

enum class TunnelState { IDLE, HANDSHAKE, CONNECTED, RECONNECTING, WAITING_NETWORK, ERROR }

/** Единственный источник истины о статусе. Flutter подписывается через EventChannel (Шаг 3). */
object VpnStateBus {
    @Volatile var state: TunnelState = TunnelState.IDLE; private set
    @Volatile var lockdownEnabled: Boolean = false
    private val listeners = CopyOnWriteArraySet<(TunnelState) -> Unit>()
    fun publish(s: TunnelState) { state = s; listeners.forEach { it(s) } }
    fun subscribe(l: (TunnelState) -> Unit) = listeners.add(l)
    fun unsubscribe(l: (TunnelState) -> Unit) = listeners.remove(l)
}

/** Логируем ТОЛЬКО статические коды и только в debug. Никаких IP, ключей, конфигов. */
object SafeLog {
    @Volatile var debuggable = false
    fun w(code: String) { if (debuggable) android.util.Log.w("Lumen", code) }
}

/** Ядро Xray (libXray / gomobile). Реализация зависит от выбранной сборки. */
interface XrayCore {
    /** Запускает ядро; onExit вызывается, если ядро завершилось само. */
    fun start(configJson: String, onExit: () -> Unit)
    fun stop()
}

/** Мост TUN -> локальный SOCKS (hev-socks5-tunnel или аналог). */
interface TunBridge {
    fun start(tunFd: Int, socksPort: Int, user: String, pass: String)
    fun stop()
}

/**
 * Адаптеры-заглушки. Подключите реальные вызовы вашей сборки:
 *  - libXray: запуск ядра из JSON-конфига и остановка;
 *  - tun2socks: запуск с fd и параметрами SOCKS (адрес 127.0.0.1, udp=on, логи off),
 *    файл конфигурации писать в cacheDir с правами 600 и удалять сразу после старта.
 * Заглушки бросают NotImplementedError — сервис ловит Throwable и уходит в ERROR.
 */
object CoreFactory {
    fun newCore(onExit: () -> Unit = {}): XrayCore = object : XrayCore {
        override fun start(configJson: String, onExit: () -> Unit) = TODO("bind libXray start")
        override fun stop() = TODO("bind libXray stop")
    }
    fun newTun(): TunBridge = object : TunBridge {
        override fun start(tunFd: Int, socksPort: Int, user: String, pass: String) = TODO("bind tun2socks start")
        override fun stop() = TODO("bind tun2socks stop")
    }
}
